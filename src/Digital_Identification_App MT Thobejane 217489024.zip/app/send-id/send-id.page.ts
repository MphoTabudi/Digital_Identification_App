import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-send-id',
  templateUrl: './send-id.page.html',
  styleUrls: ['./send-id.page.scss'],
})
export class SendIdPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  mailID() {

  }
}
